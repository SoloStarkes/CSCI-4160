The training code can be run normally as such:

python .\train_buildings.py